CS 6301.002.  Implementation of advanced data structures and algorithms
Spring 2016;
Long project 3: Shortest pathsMar 27

Group 10
Gaurav Ketkar
Madhuri Abnave
Vijay Mungara
Malav Shah

Level 1: Compile and Run SPath.java 
Level 2: Compile and Run TotalShortestPaths.java

input format: 
both program take input txt file name from command line, and also graph input from console

example: SPath <filename.txt>

or 

Sample inputs: 
8 12
1 2 1
1 4 1
2 5 1
2 4 1
5 7 1
3 1 1
3 6 1
4 3 1
7 6 1
4 5 1
4 7 1
4 6 1



